library(tidyverse)
library(ggtext)
source('scripts/utils/backbone_params-graphs.R')
source('scripts/utils/backbone_functions.R')
source('scripts/utils/params_biogem.R')


fig.path <- 'results/figures/gene_variant_calling_trend/'
dir.create(fig.path)

ab.raw.filt <- read_rds('data/04_table_gen/abtblraw_filt0rem_8sams.rds') 
genes.sel <- unique(ab.raw.filt$genename)
ab.bowtie <- read_tsv('data/04_table_gen/SELraw.counts.tbl')
ab.bowtie.long <- ab.bowtie %>%
 pivot_longer( names_to = 'sample', values_to = 'count', -gene) %>%
 filter(gene > 0) %>%
 rename('genename' = gene)
 # filter(genename %in% genes.sel)
ab.raw.filt <- ab.bowtie.long

envdata <- read_tsv('data/metadata-raw/metadata_Blanes_compact_may2017.tsv')
annot <- read_rds('data/intermediate_files/annotation.rds')
  
tax <- read_tsv('data/04_taxgenes/taxonomyresult.tsv',
                col_names = c('genename', 'genomeid', 'last_rank',
                              'rank_name', 'taxonomy')) %>% 
  separate(col = taxonomy,
           into = c("species","genus","family",
                    "order","class","phylum","superkingdom"), sep = ";") %>% 
  mutate( label = case_when(is.na(phylum) ~ rank_name,
                                 !is.na(phylum) ~ str_c(phylum, family,sep = ", "),
                                 TRUE ~ rank_name))

lomb <- readRDS('data/intermediate_files/genes_seasonal.rds')


# I will extract at least preliminary from here CODHI too
ab.mega <- ab.raw.filt %>% 
  left_join(annot, by = 'genename') %>% 
  filter(!gene_name %in% c('hao', 'nifH', 'chiA', 'CODHI', 'CODHII')) %>%
  left_join(envdata, by = c('sample' = 'Sample_name')) %>% 
  left_join(lomb %>% select(genename, peak), by = 'genename') %>% 
  mutate( seasonal = ifelse( !is.na(peak), TRUE, FALSE),
          count = ifelse(count < 0, count + 0,count))


# OPTION 1: the bar -------------------------------------------------------

labeller.df <- tibble( gene_name = gene.order) %>% 
  mutate( label = ifelse(gene_name %in% gene.italics, 
                         str_c('*', gene_name, '*'),
                         gene_name))

gene.data <- ab.mega %>%
  select(sample, genename, gene_name, count, month) %>% 
  left_join(tax, by = 'genename') %>% 
  mutate(family = ifelse(is.na(family), 'Other', family)) %>% 
  mutate(family = fct_other(family,
                            keep = family.selection,
                            other_level = 'Other') %>% as.character()) %>% 
  mutate(
    family = case_when(
      family == 'Other' & class == 'Alphaproteobacteria' ~ 'Other Alpha',
      family == 'Other' & class == 'Gammaproteobacteria' ~ 'Other Gamma',
      TRUE ~ family)) %>% 
  group_by(gene_name, sample) %>% 
  mutate(relab = count / sum(count))  %>% 
  group_by(gene_name, family, month) %>% 
  summarize(relab.month = sum(relab))

# since some taxonomy is not present in some months we will need to 
# play a little with the values to add them
gene.data.c <- complete(gene.data %>% ungroup(),
                        month, nesting(gene_name, family),
                        fill = list(relab.month = 0)) %>% 
  mutate(gene_name = ifelse(gene_name %in% gene.italics,
                            str_c('*', gene_name, '*'),
                            gene_name) %>% 
           factor(., levels = labeller.df$label))


areaplot <- ggplot( gene.data.c, aes(month, relab.month, fill = family)) + 
  geom_area( stat = 'identity', position = 'fill') + 
  facet_wrap(~gene_name ) + 
  lil.strip +
  # scale_fill_ptol(name = 'Family') +
  scale_y_continuous(labels = scales::percent) + 
  scale_x_continuous(breaks = 1:12,
                     labels = month.order %>% str_to_title() %>% str_sub(1,1),
                     name = 'Month') + 
  ylab('Relative abundance (samples aggregated by month)') +
  theme(strip.text.x = element_markdown())

  
ggsave(plot = areaplot,
       filename = str_c(fig.path, 'varplot_all_bwa.pdf'),
       width = 10,
       height = 7)


library(tidyverse)
library(pheatmap)
source('scripts/utils/backbone_params-graphs.R')
source('scripts/utils/backbone_functions.R')
source('scripts/utils/params_biogem.R')


fig.path <- 'results/figures/gene_variant_calling_trend/'
dir.create(fig.path)

ab.alr.filt <- read_rds('data/04_table_gen/abtblalr_filt0rem_8sams.rds') 
ab.raw.filt <- read_rds('data/04_table_gen/abtblraw_filt0rem_8sams.rds') 
ab.rawcount.tbl <- read_rds('data/03_mapping/abtable_raw_famli.rds')  %>% 
  rename( 'genename' = sseqid)
envdata <- read_tsv('data/metadata-raw/metadata_Blanes_compact_may2017.tsv')
annot <- read_rds('data/intermediate_files/annotation.rds')
  
tax <- read_tsv('data/04_taxgenes/taxonomyresult.tsv',
                col_names = c('genename', 'genomeid', 'last_rank',
                              'rank_name', 'taxonomy')) %>% 
  separate(col = taxonomy,
           into = c("species","genus","family",
                    "order","class","phylum","superkingdom"), sep = ";") %>% 
  mutate( label = case_when(is.na(phylum) ~ rank_name,
                                 !is.na(phylum) ~ str_c(phylum, family,sep = ", "),
                                 TRUE ~ rank_name))

lomb <- readRDS('data/intermediate_files/genes_seasonal.rds')

ab.mega <- ab.raw.filt %>% 
  left_join(annot, by = 'genename') %>% 
  left_join(envdata, by = c('sample' = 'Sample_name')) %>% 
  left_join(lomb %>% select(genename, peak), by = 'genename') %>% 
  mutate( seasonal = ifelse( !is.na(peak), TRUE, FALSE),
          count = ifelse(count < 0, count + 0,count))



# OPTION 1: the bar -------------------------------------------------------


summ.month.relab <- ab.mega %>% 
  group_by(gene_name, sample) %>% 
  mutate(relab = count / sum(count)) %>% 
  group_by(gene_name, month) %>% 
  mutate(relab.month = relab / sum(relab)) %>% 
  # select(genename, gene_name, sample,year, month, relab, relab.month) %>% 
  left_join(tax, by = 'genename')
  


name.variants <- summ.month.relab$gene_name %>% unique()  

plot.vars <- name.variants %>% 
  map(~summ.month.relab  %>% 
        filter(gene_name == .x) %>% 
        select(genename, gene_name, relab.month,
               month, phylum, class, order, family, genus) %>% 
        mutate(family = forcats::fct_lump(family, n = 4)) %>% 
        ggplot(aes(month, relab.month)) + 
        geom_bar(stat = 'identity', aes(fill = family)) + 
        scale_fill_ptol() + 
        facet_wrap(~gene_name))


fig.bar <- str_c(fig.path, 'bar_opt/')
dir.create(fig.bar)

filenames <- str_c( fig.bar, name.variants, '.pdf')

map2(filenames, plot.vars, ggsave, width = 9, height= 6)


# OPTION 2: the heat ------------------------------------------------
fig.heat <- str_c(fig.path, 'heat_opt/')
dir.create(fig.heat)

# total relab contribution for each gene 
total.relab.gene <- ab.mega %>% 
  select(genename, gene_name, count) %>% 
  group_by(gene_name) %>% 
  mutate( relab = count / sum(count)) %>% 
  distinct()
  

# the top 5 gene variants 
top5_genvars <- ab.mega %>% 
  group_by(annotation, genename) %>% 
  summarise( mean.sam = mean(count)) %>% 
  top_n(n = 5, wt = mean.sam)  %>% 
  arrange(annotation,-mean.sam)  %>% 
  mutate(varnum = factor(genename,
                         levels = unique(genename),
                         labels = str_c('Var. ', 1:length(genename)) 
                         ))  %>% 
  ungroup()

# How much total relative abundance does these selected vars represent 
total.relab.gene %>% 
  filter(genename %in%  top5_genvars$genename) %>% 
  group_by(gene_name) %>% 
  summarize( totals = sum(relab)) %>% 
  arrange(-totals) %>% 
  ggplot(aes( y = fct_inorder(gene_name), x = totals)) + 
  geom_bar(stat = 'identity') + 
  ggtitle('Amount of relative abundance explained by the top5 variants')


ggsave(filename = str_c(fig.path, 'explained_gene_var.pdf'))


# Let's generate the heatmap 

cycle.gene.list <- annot %>% 
  select(genename, cycle) %>% 
  split(.$cycle) %>% 
  map(~.x %>% pull(genename))

gene.selection <- top5_genvars$genename

# the data to plot 
ab.alr.top.mat <-  ab.alr.filt %>% 
  filter( genename %in% gene.selection)  %>% 
  pivot_wider(names_from = genename, values_from = count) %>% 
  column_to_rownames(var = 'sample' ) %>% 
  as.matrix() %>% 
  t()
  
# annotation values 
annot.df <- tibble(genename = gene.selection) %>% 
  left_join(annot, by = 'genename') %>% 
  select(genename, gene_name) %>% 
  column_to_rownames(var = 'genename')
  

labels.gene <- tibble(genename = gene.selection) %>% 
  left_join(annot, by = 'genename') %>% 
  left_join(top5_genvars %>% select(genename, varnum), by = 'genename')  %>% 
  mutate(label = str_c(gene_name, varnum) %>% str_replace(., 'Var.', ' ')) %>% 
  select(genename, label) %>% 
  column_to_rownames(var = 'genename') 
  


pheatmap(ab.alr.top.mat,
         annotation_row = annot.df, 
         labels_row = labels.gene$label,
         cluster_cols = F,
         cellwidth = 8, cellheight = 8,
         filename = str_c(fig.heat, 'heatmap_opt.pdf'))


## carbon 

carbon.genes <- intersect(cycle.gene.list$carbon, top5_genvars$genename)

pheatmap(ab.alr.top.mat[carbon.genes,],
         annotation_row = annot.df, 
         labels_row = labels.gene[carbon.genes,'label'],
         cluster_cols = F,
         cellwidth = 8, cellheight = 8,
         filename = str_c(fig.heat, 'heatmap_carbon.pdf'))


## the nitrogen 
nitro.genes <- intersect(cycle.gene.list$nitrogen, top5_genvars$genename)

pheatmap(ab.alr.top.mat[nitro.genes,],
         annotation_row = annot.df, 
         labels_row = labels.gene[nitro.genes,'label'],
         cluster_cols = F,
         cellwidth = 8, cellheight = 8,
         filename = str_c(fig.heat, 'heatmap_nitrogen.pdf'))

## the phosphor
pho.genes <- intersect(cycle.gene.list$phosporous, top5_genvars$genename)

pheatmap(ab.alr.top.mat[pho.genes,],
         annotation_row = annot.df, 
         labels_row = labels.gene[pho.genes,'label'],
         cluster_cols = F,
         cellwidth = 8, cellheight = 8,
         filename = str_c(fig.heat, 'heatmap_phos.pdf'))

## Other


# OPTION 3: the wiggle lines ----------------------------------------------

fig.lines <- str_c(fig.path, 'wiggle_lines/')
dir.create(fig.lines)

# for each gene, what are the top 5 families 
selection.fams <- total.relab.gene %>% 
  left_join(tax, by = 'genename') %>% 
  filter(!is.na(family)) %>% 
  group_by(gene_name, family) %>% 
  summarise( total.fam = sum(relab)) %>% 
  slice_max(total.fam, n = 5) %>% 
  mutate( cumsum.relab = cumsum(total.fam)) %>% 
  filter(cumsum.relab >= 0.6, total.fam >= 0.05)
  

# Let's try to plot this shit 
# First only for one specific group then for everyone 

selected.genenames <- annot %>% 
  left_join(tax, by = 'genename') %>% 
  right_join(selection.fams, by = c('gene_name', 'family'))
  

# Since some families presenting too many variants, maybe we can filter them
selected.genenames.filt <- total.relab.gene %>% 
  filter(genename %in% selected.genenames$genename) %>% 
  left_join(tax, by = 'genename') %>% 
  group_by(gene_name, family) %>% 
  slice_max(relab, n = 15)

  

ab.alr.mega <-  ab.alr.filt %>% 
  filter(genename %in% selected.genenames.filt$genename) %>% 
  left_join(tax, by = 'genename') %>% 
  left_join(annot, by = 'genename') %>% 
  left_join(envdata, by = c('sample' = 'Sample_name')) 


thegenes <- ab.alr.mega$gene_name %>% unique()

plot.families <- thegenes %>%
  map(~ab.alr.mega %>% 
        filter(gene_name %in% .x) %>% 
        ggplot(aes(day_of_year, count)) + 
        stat_smooth(aes(x = day_of_year,
                        group = genename, 
                        color = genus), 
                    method = "gam",
                    se = FALSE,
                    formula = y ~ s(x, k =12, bs = 'cc'), 
                    show.legend = TRUE) + 
        facet_wrap(~family) + 
                   # scale = 'free_y') +
        lil.strip + 
        leg.bottom + 
        scale_dayyear_shrt + 
        xlab('Day of the year (labelled by month)') + 
        ylab('Log10 ratio (gene read count / geomean(single copy genes))'))
  

filenames <- str_c(fig.lines, thegenes, '_fam_lines.pdf') 

map2(filenames, plot.families, ggsave, width = 9, height = 7)
